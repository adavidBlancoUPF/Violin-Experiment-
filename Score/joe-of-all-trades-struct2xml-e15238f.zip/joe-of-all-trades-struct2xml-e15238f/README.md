# struct2xml
MATLAB function that converts a structure into xml format ( or file ). 
