Matlab MIDI toolbox

Downloaded from:

http://www.jyu.fi/hum/laitokset/musiikki/en/research/coe/materials/miditoolbox/

Credits:

Petri Toiviainen (Professor) and Tuomas Eerola (Senior assistant) are employed at the Department of Music of the University of Jyv�skyl�, Finland. Both are members of the Music Cognition Team, which investigates various issues relating to music cognition. If you have any comments or problems to report, please contact the authors (firstname.lastname at campus.jyu.fi). 